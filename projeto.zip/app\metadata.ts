import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Studio Donna Patty",
  description: "Seu cuidado com a sua beleza é o nosso maior compromisso.",
};
